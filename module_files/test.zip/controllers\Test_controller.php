<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_controller extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Test_model');
        $this->load->library('form_validation');
    }

    public function add_test(){
        

        if ($this->form_validation->run() === FALSE) {
            $data['test_list'] = $this->Test_model->get_all_test();
            $data['single'] = $this->Test_model->get_single_test();
            $this->load->view('test', $data);
        } else {
            $result = $this->Test_model->add_test();

            if ($result == "0") {
                $this->session->set_flashdata('success', 'Record inserted successfully');
            } else {
                $this->session->set_flashdata('success', 'Record updated successfully');
            }

            redirect('test');
        }
    }

    public function test_list() {
        $data['test_list'] = $this->Test_model->get_all_test();
        $this->load->view('test_list', $data);
    }
}