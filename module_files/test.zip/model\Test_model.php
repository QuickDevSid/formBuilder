<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_model extends CI_Model {

    public function add_test(){
        $data = array(
            'name' => $this->input->post('name')
        );

        if($this->input->post('id') == ""){
            $date = array(
                'created_on' => date("Y-m-d H:i:s")
            );
            $new_arr = array_merge($data, $date);
            $this->db->insert('tbl_test', $new_arr);
            return 0;
        } else {
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('tbl_test', $data);
            return 1;
        }
    }

    public function get_all_test(){
        $this->db->where('is_deleted', '0');
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get('tbl_test');
        return $result->result();
    }

    public function get_single_test(){
        $this->db->where('is_deleted', '0');
        $this->db->where('id', $this->uri->segment(2));
        $result = $this->db->get('tbl_test');
        return $result->row();
    }


    public function get_all_test_ajax($length, $start, $search){
        $this->db->where('tbl_test.is_deleted', '0');
        if ($this->input->post('name') != "") {
            $this->db->where('tbl_test.name', $this->input->post('name'));
        }
        if ($search != "") {
            $this->db->group_start();
                $this->db->like('tbl_test.name', $search);
            $this->db->group_end();
        }
        $this->db->order_by('tbl_test.id', 'DESC');
        $this->db->limit($length, $start);
        $result = $this->db->get('tbl_test');
        return $result->result();
    }

    public function get_all_test_count_ajax($search){
        $this->db->where('tbl_test.is_deleted', '0');
        if ($this->input->post('name') != "") {
            $this->db->where('tbl_test.name', $this->input->post('name'));
        }
        if ($search != "") {
            $this->db->group_start();
                $this->db->like('tbl_test.name', $search);
            $this->db->group_end();
        }
        $result = $this->db->get('tbl_test');
        return $result->num_rows();
    }

}