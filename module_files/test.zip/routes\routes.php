<?php defined("BASEPATH") or exit("No direct script access allowed");

// Auto-generated routes for module: test
$route['test'] = 'Test_controller/add_test';
$route['test/(:any)'] = 'Test_controller/add_test/$1';
$route['test_list'] = 'Test_controller/test_list';