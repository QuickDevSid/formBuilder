<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>test List</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <table class="table table-striped responsive-utilities jambo_table" style="width: 100%;" id="example">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Name</th>

                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Data to be populated via AJAX or controller -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- External JS Includes -->
<script>
    var BASE_URL = '<?=base_url(); ?>';
    var tableElement = 'example';
    var fileName = 'test-list';
    var exportColumns = [0,1];
</script>
<script src="<?= base_url('assets/js/modules/test_custom_js.js') ?>"></script>