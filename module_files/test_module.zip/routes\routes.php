<?php defined("BASEPATH") or exit("No direct script access allowed");

// Auto-generated routes for module: test_module
$route['test_module'] = 'Test_module_controller/add_test_module';
$route['test_module/(:any)'] = 'Test_module_controller/add_test_module/$1';
$route['test_module_list'] = 'Test_module_controller/test_module_list';