<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_module_controller extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Test_module_model');
        $this->load->library('form_validation');
    }

    public function add_test_module(){
        $this->form_validation->set_rules('name', 'Name', 'required');

        if ($this->form_validation->run() === FALSE) {
            $data['test_module_list'] = $this->Test_module_model->get_all_test_module();
            $data['single'] = $this->Test_module_model->get_single_test_module();
            $this->load->view('test_module', $data);
        } else {
            $result = $this->Test_module_model->add_test_module();

            if ($result == "0") {
                $this->session->set_flashdata('success', 'Record inserted successfully');
            } else {
                $this->session->set_flashdata('success', 'Record updated successfully');
            }

            redirect('test_module');
        }
    }

    public function test_module_list() {
        $data['test_module_list'] = $this->Test_module_model->get_all_test_module();
        $this->load->view('test_module_list', $data);
    }
}