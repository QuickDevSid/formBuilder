$(document).ready(function () {
    var oldExportAction = function (self, e, dt, button, config) {
        if (button[0].className.indexOf('buttons-excel') >= 0) {
            if ($.fn.dataTable.ext.buttons.excelHtml5.available(dt, config)) {
                $.fn.dataTable.ext.buttons.excelHtml5.action.call(self, e, dt, button, config);
            } else {
                $.fn.dataTable.ext.buttons.excelFlash.action.call(self, e, dt, button, config);
            }
        } else if (button[0].className.indexOf('buttons-print') >= 0) {
            $.fn.dataTable.ext.buttons.print.action(e, dt, button, config);
        }
    };

    var newExportAction = function (e, dt, button, config) {
        var self = this;
        var oldStart = dt.settings()[0]._iDisplayStart;
        dt.one('preXhr', function (e, s, data) {
            data.start = 0;
            data.length = 2147483647;
            dt.one('preDraw', function (e, settings) {
                oldExportAction(self, e, dt, button, config);
                dt.one('preXhr', function (e, s, data) {
                    settings._iDisplayStart = oldStart;
                    data.start = oldStart;
                });
                setTimeout(dt.ajax.reload, 0);
                return false;
            });
        });
        dt.ajax.reload();
    };

    // DataTable initialization
    var table = $('#' + tableElement).DataTable({
        lengthChange: true,
        lengthMenu: [10, 25, 50, 100, 200],
        searching: true,
        responsive: true,
        processing: true,
        serverSide: true,
        cache: false,
        order: [],
        columnDefs: [
            { orderable: false, targets: "_all" }
        ],
        buttons: [
            {
                extend: "excelHtml5",
                messageBottom: '',
                filename: fileName,
                exportOptions: {
                    columns: exportColumns,
                    modifier: {
                        search: 'applied',
                        order: 'applied'
                    }
                },
                action: newExportAction
            }
        ],
        dom: "Blfrtip",
        scrollX: true,
        ajax: {
            url: BASE_URL + "Test_module_ajax_controller/get_test_module_data_ajx",
            type: "POST",
            data: function (d) {}
        },
        complete: function () {
            $('[data-toggle="tooltip"]').tooltip();
        }
    });

    // Form validation
    $('#' + formElement).validate({
        ignore: [],
        rules: {
            'new_field': { required: true }
        },
        messages: {
            'new_field': { required: 'Please enter New Field!' }
        },
        errorElement: 'span',
        errorPlacement: function (error, element) {
            error.addClass('invalid-feedback');
            element.closest('.form-group').append(error);
        },
        highlight: function (element, errorClass, validClass) {
            $(element).addClass('is-invalid');
        },
        unhighlight: function (element, errorClass, validClass) {
            $(element).removeClass('is-invalid');
        },
        submitHandler: function (form) {
            form.submit();
        }
    });
});
    $('#new_field').on('keyup change', function () {
        $.ajax({
            type: "POST",
            url: BASE_URL + "Test_module_ajax_controller/get_unique_new_field",
            data: {
                'new_field': $('#new_field').val(),
                id: $('#hidden_id').val() || ''
            },
            success: function (data) {
                if (data == "0") {
                    $('#new_field_error').html('');
                    $('#submit').show();
                } else {
                    $('#new_field_error').html('This New Field is already added');
                    $('#submit').hide();
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
            }
        });
    });