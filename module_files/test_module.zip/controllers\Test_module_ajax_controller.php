<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test_module_ajax_controller extends CI_Controller {

    public function __construct(){
        parent::__construct();
        $this->load->model('Test_module_model');
    }


    public function get_test_module_data_ajx(){
        $draw = intval($this->input->post("draw"));
        $start = intval($this->input->post("start"));
        $length = intval($this->input->post("length"));
        $order = $this->input->post("order");
        $search = $this->input->post("search") != "" ? $this->input->post("search") : (isset($search['value']) ? $search['value'] : '');
        $col = 0;
        $dir = "";
        if(!empty($order)){
            foreach($order as $o){
                $col = $o['column'];
                $dir= $o['dir'];
            }
        }
        if($dir != "asc" && $dir != "desc"){
            $dir = "desc";
        }

        $records = $this->Test_module_model->get_all_test_module_ajax($length, $start, $search);

        $data = array();
        if(!empty($records)){
            $page = $start / $length + 1;
            $offset = ($page - 1) * $length + 1;
            foreach($records as $print){
                $sub_array = array();
                $sub_array[] = $print->new_field;
                $sub_array[] = '<span class="inline-action-btns">
                    <a href="' . base_url('test_module/' . $print->id) . '" class="edit-link" data-bs-toggle="tooltip" title="Edit">
                        <i class="icon"></i>
                    </a>
                    <a class="trigger-delete" data-title="Are you sure to delete this record?" data-message="" href="' . base_url('delete/' . $print->id . '/tbl_test_module') . '" data-bs-toggle="tooltip" title="Delete">
                        <i class="icon"></i>
                    </a>
                </span>';

            }
        }

        $total = $this->Test_module_model->get_all_test_module_count_ajax($search);

        $output = array(
            "draw" => $draw,
            "recordsTotal" => $total,
            "recordsFiltered" => $total,
            "data" => $data
        );
        echo json_encode($output);
        exit();
    }
}