<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Add test_module</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <form method="post" name="master_form" id="master_form" enctype="multipart/form-data">
                            <input type="hidden" name="hidden_id" id="hidden_id" value="<?php if(!empty($single)){ echo $single->id; }?>">
                            <div class="row">
                                    <div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <label>New Field <b class="require">*</b></label>
        <input type="text" class="form-control" name="New Field" id="New Field" value="<?php if(!empty($single)){ echo $single->New Field; }?>" placeholder="Enter New Field">
        <div class="error" id="New Field_error"></div>
    </div>

                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <button style="margin-top: 10px;" type="submit" id="submit" class="btn btn-success">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</div>

<!-- External JS Includes -->
<script>
    var BASE_URL = '<?=base_url(); ?>';
    var formElement = 'master_form';
</script>
<script src="<?= base_url('assets/js/modules/test_module_custom_js.js') ?>"></script>