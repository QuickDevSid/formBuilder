<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class New_module_two_model extends CI_Model {

    public function add_new_module_two(){
        $data = array(
            'name' => $this->input->post('name'),
            'mobile_no' => $this->input->post('mobile_no')
        );

        if($this->input->post('id') == ""){
            $date = array(
                'created_on' => date("Y-m-d H:i:s")
            );
            $new_arr = array_merge($data, $date);
            $this->db->insert('tbl_new_module_two', $new_arr);
            return 0;
        } else {
            $this->db->where('id', $this->input->post('id'));
            $this->db->update('tbl_new_module_two', $data);
            return 1;
        }
    }

    public function get_all_new_module_two(){
        $this->db->where('is_deleted', '0');
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get('tbl_new_module_two');
        return $result->result();
    }

    public function get_single_new_module_two(){
        $this->db->where('is_deleted', '0');
        $this->db->where('id', $this->uri->segment(2));
        $result = $this->db->get('tbl_new_module_two');
        return $result->row();
    }


    public function get_all_new_module_two_ajax($length, $start, $search){
        $this->db->where('tbl_new_module_two.is_deleted', '0');
        if ($this->input->post('name') != "") {
            $this->db->where('tbl_new_module_two.name', $this->input->post('name'));
        }
        if ($this->input->post('mobile_no') != "") {
            $this->db->where('tbl_new_module_two.mobile_no', $this->input->post('mobile_no'));
        }
        if ($search != "") {
            $this->db->group_start();
                $this->db->like('tbl_new_module_two.name', $search);
            $this->db->group_end();
        }
        $this->db->order_by('tbl_new_module_two.id', 'DESC');
        $this->db->limit($length, $start);
        $result = $this->db->get('tbl_new_module_two');
        return $result->result();
    }

    public function get_all_new_module_two_count_ajax($search){
        $this->db->where('tbl_new_module_two.is_deleted', '0');
        if ($this->input->post('name') != "") {
            $this->db->where('tbl_new_module_two.name', $this->input->post('name'));
        }
        if ($this->input->post('mobile_no') != "") {
            $this->db->where('tbl_new_module_two.mobile_no', $this->input->post('mobile_no'));
        }
        if ($search != "") {
            $this->db->group_start();
                $this->db->like('tbl_new_module_two.name', $search);
            $this->db->group_end();
        }
        $result = $this->db->get('tbl_new_module_two');
        return $result->num_rows();
    }

}