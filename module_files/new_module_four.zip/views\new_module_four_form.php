<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Add new_module_four</h3>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_content">
                        <form method="post" name="master_form" id="master_form" enctype="multipart/form-data">
                            <input type="hidden" name="hidden_id" id="hidden_id" value="<?php if(!empty($single)){ echo $single->id; }?>">
                            <div class="row">
                                            <div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
                <label>Name <b class="require">*</b></label>
                <select class="form-control chosen-select" name="name" id="name">
                    <option value="">Select Name</option>
                    <?php
                        $records = $this->New_module_four_model->get_dependent_data_all('tbl_test');
                        if(!empty($records)){
                            foreach($records as $row){
                                ?>
                                <option value="<?=$row->id; ?>" <?=!empty($single) && $single->name == $row->id ? 'selected' : ''; ?>>
                                    <?=$row->name; ?>
                                </option>
                                <?php
                            }
                        }
                    ?>
                </select>
                <div class="error" id="name_error"></div>
            </div>    <div class="form-group col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <label>Marks <b class="require">*</b></label>
        <input type="text" class="form-control" name="marks" id="marks" value="<?php if(!empty($single)){ echo $single->marks; }?>" placeholder="Enter Marks">
        <div class="error" id="marks_error"></div>
    </div>

                            </div>
                            <div class="row">
                                <div class="form-group col-md-12 col-sm-12 col-xs-12">
                                    <button style="margin-top: 10px;" type="submit" id="new_module_four_submit" class="btn btn-success">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</div>

<!-- External JS Includes -->
<script>
    var BASE_URL = '<?=base_url(); ?>';
    var formElement = 'master_form';
    vart submitBtn = 'new_module_four_submit';
</script>
<script src="<?= base_url('assets/js/modules/new_module_four_custom_js.js') ?>"></script>